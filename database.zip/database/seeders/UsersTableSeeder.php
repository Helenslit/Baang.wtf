<?php

namespace Database\Seeders;

use App\Providers\GenericHelperServiceProvider;
use App\Providers\ListsHelperServiceProvider;
use App\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'role_id' => DB::table('roles')->where('name', 'admin')->first()->id,
            'password' => Hash::make('test123'),
            'email' => 'test@test.com',
            'name' => 'Test',
            'username' => 'test'
        ]);

        // These have to be called after user creation
        // otherwise bugs..
        GenericHelperServiceProvider::createUserWallet($user);
        ListsHelperServiceProvider::createUserDefaultLists($user->id);
    }
}
