<?php

namespace App\Jobs;

use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Providers\EmailsServiceProvider;
use App\Providers\ListsHelperServiceProvider;
use Illuminate\Support\Facades\App;

class NotifyUsersJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $user;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        // Grabbing followers
        $followers = ListsHelperServiceProvider::getUserFollowers($this->user->id);

        // Sending them email notifications, if site & user settings allows it
        foreach($followers as $follower){
            $serializedSettings = json_decode($follower['settings']);
            if(isset($serializedSettings->notification_email_new_post_created) && $serializedSettings->notification_email_new_post_created == 'true'){
                App::setLocale($serializedSettings->locale);
                EmailsServiceProvider::sendGenericEmail(
                    [
                        'email' => $follower['email'],
                        'subject' => __('New content from @:username', ['username' => $this->user->username]),
                        'title' => __('Hello, :name,', ['name'=>$follower['name']]),
                        'content' => __('New content from people you follow is available', ['siteName'=>getSetting('site.name')]),
                        'button' => [
                            'text' => __('View your feed'),
                            'url' => route('feed'),
                        ],
                    ]
                );
                App::setLocale($this->user->settings['locale']);
            }
        }
    }
}
