<?php

namespace App\Console\Commands;

use App\Model\Attachment;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;

class MigrateFilesToS3 extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:migrate:files';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate the files from local storage to s3 bucket. ETA 2 hours.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $localDisk = Storage::disk('do_spaces');
        $s3Disk = Storage::disk('s3');

        $local_files = $localDisk->allFiles();

        $migrated_files = $s3Disk->allFiles();

        $files = array_diff($local_files, $migrated_files);

        $total = count($files);
        $CHUNK_SIZE = 5;
        $migrated = 0;

        $this->info(\Carbon\Carbon::now()->format('H:m:s'));

        $this->info("STARTING MIGRATION!");
        foreach(array_chunk($files, $CHUNK_SIZE) as $fileSet)
        {
            foreach ($fileSet as $file)
            {
                $this->info($file);
                # Upload to S3
                $s3Disk->put($file, $localDisk->get($file));
            }

            $this->info("Migrated ".$migrated." files out of ".$total."...".round(($migrated/$total)*100,2).'%');
            $migrated += $CHUNK_SIZE;
        }
        $this->info(\Carbon\Carbon::now()->format('H:m:s'));

        $this->info('Migration completed.');
    }
}
